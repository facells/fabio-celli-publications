Cultural Hacking Dataset

This dataset is released under Creative Commons Licence BY-NC-SA 4.0 international.

if you use it please cite:

Celli, F. Samal, A. 2025. Beyond Bias Detection: Monitoring Historical Cultural Hacking in Large Language Models. In proceedings of TRUST-AI: The European Workshop on Trustworthy AI. Organized as part of the European Conference of Artificial Intelligence - ECAI 2025. October 2025, Bologna, Italy.