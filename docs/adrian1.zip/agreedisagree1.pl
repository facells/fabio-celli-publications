#!/usr/bin/perl

#agreedisagree1.pl
#agreement/disagreement classification system for news blogs.
#v 1.0
#written by fabio celli at the university of Trento
#for the SENSEI european project.
#this code is released under a LGPL license
#you can contact the author at fabio.celli@live.it 

#input
my $sin=@ARGV[0]; chomp($sin);#catch input string

if($sin eq ""){ die '..HELP: input \dir OR dir\file.json like 
>perl agreedisagreee1.pl c:\my\dir\ 
';}  
@f=split/\\/,$sin; 
if($sin=~m/\.json$/i){$file=pop(@f);}; $dir=join("/", @f); #split dir and file
chdir($dir); #go to dir
my @f = do {open my $in, "<", $file or die "could not open $file";  <$in>;}; #open file in  array

#get file contents to be processed
@txt=grep/"content": ".+?"/,@f; $d=strc($txt[0]);
@aut=grep/author":/,@f; $aut=strc($aut[0]);
@xid=grep/externalID":/,@f; $xid=strc($xid[0]);
@pid=grep/postID":/,@f; $pid=strc($pid[0]);
@lng=grep/langDetected":/,@f; $lng=strc($lng[0]);
@id=grep/"id":/,@f; $id=strc("$id[0]");
@tit=grep/"name":/,@f; $tit=strc($tit[0]);


#processing: feature extraction and model application

#level0:encoding
 $lid=""; $la=0; $cj=0; $ko=0; $ar=0; $rs=0; $he=0; $hi=0; $gr=0; $th=0; $am=0; $ot=0; $dl=0; $sy=0; $langnum=0; #define vars
 $chr=0; $cng2=0; $cng3=0; $cng4=0;  #define vars
 $chr=length($d); if($chr==0){$chr=1;} #count chars print "ERR: chr=0 \@ $file line $linecount\n";
 $cj++ while $d=~m/[\xE2-\xE9][\xB8-\xBF]|\xE3[\x81-\x83]|\xE3\x84/g; #chinese, japanese, bopomofo
 $la++ while $d=~m/[a-z]/g; #latin alphabet
 $hi++ while $d=~m/\xE0[\xA4-\xB3]|\xE1[\x82-\x83]/g; #devanagari (hindi, bengali, georgian, tamil, telegu, punjabi, limbu, nepalese )
 $ar++ while $d=~m/\xD9[\x81-\xAF]/g; #arabic (arabic, syrian)
 $rs++ while $d=~m/\xD0[\xB1-\xBF]/g; #cyrillic (russian, bielorussian, bulgarian)
 $ko++ while $d=~m/[\xEC-\xED][\x91-\x9F]/g; #korean
 $th++ while $d=~m/\xE0[\xB4-\xBB]|\xE1[\x9C-\xAD]/g; #other southeastern (thai, lao, balinese, tagalog, khmer, malaylam)
 $gr++ while $d=~m/\xCE[\xB1-\xBF]/g; #greek
 $he++ while $d=~m/\xD7[\x91-\x99]/g; #hebrew
 $am++ while $d=~m/\xD4[\xB1-\xBF]|\xCF[\xA2-\xAF]|\xDF[\x80-\xBA]|\xE1[\88-\x8E]|\xE1\xAE/g; #other african (amharic, coptic, nko, ge'ez, sudanese)
 $ot++ while $d=~m/\xE1[\x8E-\x9B]|\xDE[\x80-\xB1]|\xE0[\xA0-\xA1]|\xE1[\xA0-\xA2]/g; #other alphabets (runic, cherokee, can.aboriginal, samaritan, thaana, mongolian)
 $dl++ while $d=~m/\xF0[\x90-\x96]/g; #dead languages (linearA, egyptian, cuneiform, )
 $sy++ while $d=~m/[\xC9\x90]-[\xCA\xAF]|\xE2[\x84-\xA3]/g; #symbols (ipa, math, arrows, boxes, braille)
 @enc=($cj, $la, $hi, $ar, $rs, $ko, $th, $gr, $he, $am, $ot, $dl, $sy); #list of languages ordered by num of speakers in the world
 foreach my $i(@enc){$i=sprintf("%.3f",($i/$chr)); if($i>0){$langnum++;}}; $enc=join(',',@enc);
 $lsum=msm(@enc); #summary of langs in text
 @lsum=split/,/,$lsum;
 $lnum=sprintf("%.3f",($langnum/13));
 $lidx=maxindex(@enc); if($lidx==0){$lid="c";}; if($lidx==1){$lid="l";}; if($lidx>=2){$lid="x";};
 #print "l c k a r h i g t\n";
$level0="$enc,$lsum,$lnum,$lidx"; $level0=~s/,,/,\?,/g;

#level1:chars
 $pem++ while $d =~ s/ :-\)| : \)| :\)| :-\]| : \]| :\]| =\)| =\]| :->| : >| :>| \^_\^| :-D| : D| :D| :�D| X-D| X D| XD| 8-\)| B-\)| 8 \)| B \)| ;-\)| ; \)| ;\)| ;-\]| ; \]| ;\]| ;->| ; >| ;>| :-\*| :\*| \*<:o\) / ! /g; $per=sprintf("%.4f",($pem/$chr));# count positive emoticons
 $nem++ while $d =~ s/ :-\(| : \(| :\(| :-\[| : \[| :\[| =\(| =\[| :<| =<| :'-\(| :' \(| :'\(| :'-\[| :' \[| :'\[| =' \(| ='\(| :'-<| :' <| :'<| =' <| ='<| T_T| Y_Y| �_�| :-S| : S| :S| = S| :-\?| : \?| :\?| \@_\@| :-O| :oO| o_o| O_o| o_O| >_<| x_x| :-\@| :\@| >:\(| >:\@| #_#| :-\// ! /g; $ner=sprintf("%.4f",($nem/$chr));# count negative emoticons
 $p0i=$d=~s/-|;|:|\xE3\x80\x81/ ; /g; $p0i=sprintf("%.4f",($p0i/$chr)); #count internal punctuation
 $p0f=$d=~s/\.{1,9}|\xE3\x80\x82/ \. /g; $p0f=sprintf("%.4f",($p0f/$chr));  #count final punctuation
 $p1=$d=~s/\!|\?|\xEF\xBC\x81/ \. /g; $p1=sprintf("%.4f",($p1/$chr)); #count expression marks
 $p2=$d=~ s/\xE2\x80\x9E|"/ " /g; $p2=sprintf("%.4f",($p2/$chr)); #count quotes
 $p2o=$d=~s/\xC2\xAB|\xE2\x80\xB9|\{|\[|\(/ " /g; $p2o=sprintf("%.4f",($p2o/$chr)); #count open parentheses
 $p2c=$d=~s/\xC2\xBB|\xE2\x80\xBA|\}|\]|\)/ " /g; $p2c=sprintf("%.4f",($p2c/$chr)); #count close parentheses
 $p3=$d=~s/'/ /g; $p3=sprintf("%.4f",($p3/$chr)); #count and replace apices
 $n0++ while $d =~ m/[0-9]/g; $n0=sprintf("%.4f",($n0/$chr)); #numbers
 $n1=$d=~s/\+|\-|\*|\/\%|=/ /g; $n1=sprintf("%.4f",($n1/$chr)); #operators
 $x0=$d=~s/#/ /g; $x0=sprintf("%.4f",($x0/$chr)); #hashtags
 $x1=$d=~s/\@/ /g; $x1=sprintf("%.4f",($x1/$chr)); #mentions
 $x2=$d=~s/http:\/\/|www\.+?\..{2,3} / /g; $x2=sprintf("%.4f",($x2/$chr)); #urls
 $uc++ while $d =~ m/[A-Z]/g; $uc=sprintf("%.4f",($uc/$chr)); #uppercase
 $lc++ while $d =~ m/[a-z]/g;  $lc=sprintf("%.4f",($lc/$chr)); #lowercase
 $d=~s/ {2,9}|\s/ /g; #replacing doublespaces
 if($lid eq "c"){$d=~s/;/\xE3\x80\x81/g; $d=~s/\./\xE3\x80\x82/g; $d=~s/\(|\)|"/\xE2\x80\x9E/g; $d=~s/\!/\xEF\xBC\x81/g; $d=~s/([\xE2-\xEF])/ $1/g;}; @t=split/ /,$d; #word segmentation (filtered for cj)$d=~s/(\W{3})/$1 /g;

#level1b:morpho
 $ng2=ngrams($d, 2, 2); @ng2=split/\|/,$ng2; $cng2=scalar(@ng2); $cng2=sprintf("%.3f",($cng2/$chr)); #bigrams
 $ng3=ngrams($d, 3, 2); @ng3=split/\|/,$ng3; $cng3=scalar(@ng3); $cng3=sprintf("%.3f",($cng3/$chr));#trigrams
 $ng4=ngrams($d, 4, 2); @ng4=split/\|/,$ng4; $cng4=scalar(@ng4); $cng4=sprintf("%.3f",($cng4/$chr));#tetragrams
$level1="$n0,$n1,$x0,$x1,$x2,$p0i,$p0f,$p1,$p2,$p2o,$p2c,$p3,$per,$ner,$uc,$lc,$cng2,$cng3,$cng4"; $level1=~s/,,/,\?,/g;

#level2:words
 #$text=join("\n", @t);
 $w=0;  $d1=$d; $syn=""; $prevwf=0; $wlen=0; @Swrf=(); @Ssemfl=(); $wf=0; $maxwf=0; @Swf=(); @Ssemfp=(); @keyinfo=(); @modinfo=(); @ner=(); @freqw=(); $repeatfw=0; @Sfwsim=();  #define vars
 $d1=~s/;|\.|"|\!|\xE3\x80\x81|\xE3\x80\x82|\xE2\x80\x9E|\xEF\xBC\x81//g; $d1=~s/ {2,9}/ /g; @t1=split/ /,$d1; #do not count punctuation (internal, final, emoticons, parentheses) with words
 $w=scalar(@t); if($w==0){$w=1;} $w1=scalar(@t1); if($w1==0){$w1=1;} #word count, with and without punctuation
 $pwr=sprintf("%.3f",($w1/$w)); #punctution-word ratio
 $cwr=sprintf("%.3f",($w/$chr)); #char-word ratio
 foreach my $i (@t){ #process word by word : compute wf, rwf wlen, wsem, part of speech (w, W, n, x) for syntax, keywords
  if($i!~m/;|\.|"|\!|\xE3\x80\x81|\xE3\x80\x82|\xE2\x80\x9E|\xEF\xBC\x81/){#filter out punctuation
   $wf=0; $wf++ while $d1=~m/ $i /g; $wrf=($wf/$w1);  push(@Swrf, $wrf); push(@Swf, $wf); #wrf and wf
   $wlen=length($i); #wlen
   $semfl=sen("$wf,$wlen");  push(@Ssemfl, $semfl); #w-l sem
   $mefl=msm(@Ssemfl); $mefl=~s/,+//; if($semfl>$mefl && $semfl<$mefl+0.001){push(@keyinfo, "$i,$semfl,$wf,$wlen,$prevwf,$wrf"); }; #collect keywords by sematics
   $semfp=sen("$wf,$prevwf");  push(@Ssemfp, $semfp); #w-pw sem
   $mefp=msm(@Ssemfp); $mefp=~s/,+//; if($semfp>$mefp && $semfp<$mefp+0.001){push(@modinfo, "$i,$semfl,$wf,$wlen,$prevwf,$wrf");  }; #collect modwords by sematics 
   $maxwf=max(@Swrf);   $maxwf=$maxwf-($maxwf/4); if($wrf>=$maxwf){push(@freqw, $i);}; #collect most frequent words
   #print $out "$i | wf=$wf wrf=$wrf prevwf=$prevwf len=$wlen fl=$semfl fp=$semfp \n"; 
   $prevwf=$wf;
  }
  if($i=~m/^[a-z]|^\W/){$syn=$syn."w";}; #pos label word
  if($i=~m/^[A-Z]/){$syn=$syn."W"; push(@ner, $i);}; #pos label uc word
  if($i=~m/^.[0-9]/){$syn=$syn."n";}; #pos label number
  if($i=~m/\.|\xE3\x80\x82/){$syn=$syn." ";}; #pos label eos
  if($i=~m/;|"|\!|\xE3\x80\x81|\xE2\x80\x9E|\xEF\xBC\x81/){$syn=$syn."x";} #pos label punctuation
 }; 
 $awrf=msm(@Swrf); #avg word relative freq
 @wf=split/,/,$wf;
 $cfw=scalar(@freqw); $tcfw=$cfw; $freqw=join(' ',@freqw); $rcfw=sprintf("%.3f",($tcfw/$w)); #print $out "freqwset= @freqw\n"; #relative count of freq words
 while($cfw>1){$j=shift(@freqw); foreach my $i(@freqw){if($j eq $i){$repeatfw++;}; $cfw=scalar(@freqw); };}
 $rrwf=sprintf("%.3f",($repeatfw/$w));
 #$afwsim=msm(@Sfwsim);
 $level2="$cwr,$pwr,$awrf,$rcfw,$rrwf"; $level2=~s/,,/,\?,/g;

#level3:syntax
 @Ssynsim=(); $cwg2=0; $cwg3=0; $cwg4=0; $csg2=0; $csg3=0; $csg4=0; 
 @syn=split/ /,$syn; $csyn=scalar(@syn); if($csyn==0){$csyn=1;} #total syntag
 $tcsyn=sprintf("%.3f",($csyn/$w)); #ratio between syn sentences and words
 $wg2=wngrams($d, 2, 2, 19); @wg2=split/\|/,$wg2; $cwg2=sprintf("%.3f",(scalar(@wg2)/$csyn)); push(@ner, @wg2); #bigrams
 $wg3=wngrams($d, 3, 2, 19); @wg3=split/\|/,$wg3; $cwg3=sprintf("%.3f",(scalar(@wg3)/$csyn)); #push(@ner, @wg3); #trigrams
 $wg4=wngrams($d, 4, 2, 19); @wg4=split/\|/,$wg4; $cwg4=sprintf("%.3f",(scalar(@wg4)/$csyn)); #push(@ner, @wg4); #tetragrams
 $sg2=ngrams($syn, 2, 1); @sg2=split/\|/,$sg2; $csg2=scalar(@sg2); $csg2=sprintf("%.3f",($csg2/$csyn)); #wtype bigrams
 $sg3=ngrams($syn, 3, 1); @sg3=split/\|/,$sg3; $csg3=scalar(@sg3); $csg3=sprintf("%.3f",($csg3/$csyn));#wtype trigrams
 $sg4=ngrams($syn, 4, 1); @sg4=split/\|/,$sg4; $csg4=scalar(@sg4); $csg4=sprintf("%.3f",($csg4/$csyn));#wtype tetragrams
 while($csyn>1){$j=shift(@syn); foreach my $i(@syn){$synsim=sim($j, $i); push(@Ssynsim, $synsim);}; $csyn=scalar(@syn); } #compute similarity between syn sentences
 $asynsim=msm(@Ssynsim);
 @synsim=split/,/,$asynsim;

#level3b:named entities and compounds
 #print $out "ner= @ner\n";
 $ners=join('|',@ner); #create a string of ner for level 7
 $cner=scalar(@ner); $tcner=$cner; $repeatner=0; $rcner=sprintf("%.3f",($cner/$w)); #count all NER and words in bigrams collected at level 2 and 3 
 while($cner>1){$j=shift(@ner); foreach my $i(@ner){if($j eq $i){$repeatner++;}; if($j ne "" && $i ne "" && $j ne $i){$nersim=sim($j, $i); push(@Snersim, $nersim);}; $cner=scalar(@ner); } } #compute similarity between named entities words
 $anersim=msm(@Snersim); #mean and sd of similarity between named entities
 @nersim=split/,/,$anersym;
 $totner=sprintf("%.3f",(($tcner-$repeatner)/$w1));
 $level3="$tcsyn,$asynsim,$cwg2,$cwg3,$cwg4,$csg2,$csg3,$csg4,$rcner,$totner,$anersim"; $level3=~s/,,/,\?,/g; #print "$level3\n";

#evel4:semantics
 $aflr=msm(@Ssemfl); #avg w freq-len radius 
 @flr=split/,/,$aflr;

#level4b:semantic relations
 $afpr=msm(@Ssemfp); #avg w freq-prev w freq radius
 @fpr=split/,/,$afpr;
 @sre=(); $csre=scalar(@sre); #define vars
 foreach $i(@modinfo){@sfp=split/,/,$i; push(@sre, $sfp[0]);}; $sres=join(' ',@sre); #extract semantic values from modinfo, create string for level7
 $csre=scalar(@sre); $tcsre=$csre; #$rcsre=sprintf("%.3f",$tcsre/$w1); #print $out "sre=@sre\n"; 
# while($csre>1){$j=shift(@sre); foreach my $i(@sre){ if($j != 0 && $i != 0 && $j != $i){$sredst=dst($j, $i); print $out "$i & $j sredst=$sredst\n"; push(@Ssredst, $sredst);}; $csre=scalar(@sre); } } #compute distance between semantics of words
# $asredst=msm(@Ssredst);  #mean and sd of sre(distance between words)
 $totsre=sprintf("%.3f",($csre/$w1)); #count all w semantically related to a word, collected at level 2 
 $level4="$aflr,$afpr,$totsre"; $level4=~s/,,/,\?,/g;

#level5:keywords
 @keyw=(); $repeatkeyw=0; #define vars
 foreach $i(@keyinfo){@sem=split/,/,$i; push(@keyw, $sem[0]);}; $keyws=join(' ',@keyw); #extract keyw strings from keyinfo, create string for level7
 $ckeyw=scalar(@keyw); $tckeyw=$ckeyw; $rckeyw=sprintf("%.3f",$ckeyw/$w1); #print $out "keyw=@keyw\n"; #count all keyws collected at level 2 
 while($ckeyw>1){$j=shift(@keyw); foreach my $i(@keyw){if($j eq $i){$repeatkeyw++;}; $ckeyw=scalar(@keyw); } } #compute repeated keyws
 if($tckeyw==0){$rrepeatkeyw=0.000;}else{ $rrepeatkeyw=sprintf("%.3f",$repeatkeyw/$tckeyw);} #ratio of repeated keywords over all keywords
 $totkeyw=sprintf("%.3f",(($tckeyw-$repeatkeyw)/$w1)); #relative keywords (without repetition) over all words
 $level5="$rckeyw,$rrepeatkeyw,$totkeyw"; $level5=~s/,,/,\?,/g; #print "$level5\n";

#level6:sentiment
 $sentw=sprintf("%.3f",(($pem-$nem)/$w1)); #compute sentiment from emoticons over total words
 $tote=sprintf("%.3f",($pem+$nem)/$w); #compute total of sentiment in text
 $level6="$sentw,$tote"; $level6=~s/,,/,\?,/g;


#level7:documents (tf*idf over sentences) computes how much the document is focussed on a topic.
 $d2=$d; 
 $d2=~s/\.{1,9}|\xE3\x80\x82 |\!{1,9} |\?{1,9} |\xEF\xBC\x81 |\|EOL\|/ \n /g; #doc/sentence segmentation
 @d2=split/\n/,$d2; $d2c=scalar(@d2); $rwpd=sprintf("%.3f",($d2c/$w1)); #ratio between words and docs
 @dtfidf=tfidf($d2); #print @tfidf;
 $docmsm=msm(@tfidf); #statistics about tf*idf
 @docmsm=split/,/,$docmsm;
 $level7="$docmsm,$rwpd"; $level7=~s/,,/,\?,/g;  

#feature vector creation
 $featureset="$level0,$level1,$level2,$level3,$level4,$level5,$level6,$level7"; @featcount=split/,/,$featureset; $featsetcount=scalar(@featcount);
 #print "$featureset,$classes\n";
 $classes=~s/ /-/g;

#apply models
=cut
 $agree=sprintf("%.3f",((-0.0511 * $n1) + (0.1606 * $x0) + (-0.0243 * $x1) + (0.4666 * $p0i) + (0.2974 * $p2) + (-0.606  * $p3) + (0.248  * $uc) + (0.0767 * $cng4) + (-1.4088 * $cwr) + (1.7004 * $totner) + (-0.6824 * $nersim[0]) + (-1.8475 * $fpr[1]) +  0.7293));
=cut
 $adscore=sprintf("%.3f",((-79.8654 * $x1) + (9.2381 * $p0i) + (-4.9107 * $p3) + (-3.0009 * $cwr) + (0.7808 * $totner) + (-7.9372 * $nersim[0]) + (-0.7444 * $fpr[1]) +0.73));
 #print "$adscore x1=$x1 p0i=$p0i $featureset d=$d\n"; 
 if($adscore>0){$adlabel="agr";}elsif($adscore<=0){$adlabel="dis";}else{$adlabel="NA";}


 
#format output
$ad="{ \"comment\":\"\", \"lang\":\"$lng\", \"content\":\"\", \"annotationMap\":{ \"agree\":[ { \"type\":\"rel\", \"id\":$id, \"score\":$adscore, \"label\":\"$adlabel\" }, { \"type\":\"parent\", \"rel_id\":$id, \"post_id\":$pid, \"post_auth\":\"\" }, { \"type\":\"child\", \"rel_id\":$id, \"post_id\":$xid, \"post_auth\":\"$aut\" } ] } }";
if($d==0){$ad="{ \"comment\":\"\", \"lang\":\"$lng\", \"content\":\"\", \"annotationMap\":{ \"agree\":[ { \"type\":\"rel\", \"id\":$id, \"score\":none, \"label\":\"NA\" },  { \"type\":\"parent\", \"rel_id\":$id, \"post_id\":$pid, \"post_auth\":\"\" }, { \"type\":\"child\", \"rel_id\":$id, \"post_id\":$xid, \"post_auth\":\"$aut\" } ] } }";
}


#output
open $out, ">", "$file-agr.json" or die "could not open output, $!";
print $out $ad;
close $out;
#chdir($dir);



#functions
sub strc{#clean strings
$s=@_[0]; #print "s = $s";
@str=split/": /,$s;
$s=$str[1]; 
$s=~s/"|,$|, $//g;
chomp($s);
return $s;

}



sub min{#retrieve min value of an array
my ($min, @vars) = @_;
for (@vars) {$min = $_ if $_ < $min;}
return $min;
}

sub max{#retrieve max value of an array
my ($max, @vars) = @_;
for (@vars) {$max = $_ if $_ > $max;}
return $max;
}

sub maxindex{ #returns index of the max element in array. parameter: 1 array
@a=@_;
sub max{
my ($max, @vars) = @_;
for (@vars) {$max = $_ if $_ > $max;}
return $max;
} 
$m=max(@a);
$n=0;
foreach my $i (@a){ if($i==$m){$index=$n;} $n++; }
return $index;
} 

sub ngrams{ #input@: 0.text 1.gram-num 2.min-freq of n-grams returned. return$ with ngrams separated by |
$n=$_[1]; $txt=$_[0]; $l=length($txt); $f=$_[2]; 
$i=0; $j=($l-$n); #print "l=$l f=$f n=$n j=$j \n";
$dict="|"; $buff="|"; $freq=0;
while($i <= $j){
$gram=substr($txt, $i, $n); $gram=quotemeta($gram); 
$freq++ while $buff =~ m/\|$gram\|/g;  #push(@frq, $freq); $meanfrq=mean(@frq);  print "freq=$freq mean=$meanfrq";
if($freq > $f){if($dict!~ m/\|$gram\|/){$dict="$dict$gram|";} }else{$buff="$buff$gram|";};
$i++ ;
$freq=0;
}
return $dict;
}

sub wngrams{ #input 0.text 1.num 2.min-freq 3.rank filter. return$ with ngrams separated by |
sub maxindex{ #1 num
@a=@_;
sub max{
my ($max, @vars) = @_;
for (@vars) {$max = $_ if $_ > $max;}
return $max;
} 
$m=max(@a);
$n=0;
foreach my $i (@a){ if($i==$m){$index=$n;} $n++; }
return $index;
} 
$n=$_[1]; $txt=$_[0];  $mf=$_[2]; $rnk=$_[3];
$txt=~s/\n/ /g; $txt=~s/  / /g;  
@txt=split/ /,$txt; $l=scalar(@txt);
$i=0; $j=$i+($n-1); #print "l=$l f=$f n=$n j=$j \n";
$dict=""; $buff=""; 
foreach $x (@txt){
$freq=0;
@gram=@txt[$i,$j]; $gram=join(' ', @gram); $gramq=quotemeta($gram);
$freq++ while $txt =~ m/ $gramq /g; #print "freq=$freq $gram  \n"; #-> dic=$dict buf=$buff
if($freq >= $mf && $buff!~ m/\|$gramq\|/){push(@freqs,$freq); push(@grams,$gram); $buff="$buff|$gram|";}

#if($freq >= 1){if($dict!~ m/\|$gram\|/){$dict="$dict$gram|";} }else{$buff="$buff$gram|";};

$i++ ; $j++ ;
$freq=0;
}
#print "freqs=@freqs \ngrams=@grams \n";  
$cyc=1;
while($cyc<=$rnk){
$mi=maxindex(@freqs); 
$mygram=$grams[$mi]; #print "mygram=$mygram mi=$mi\n";
if($dict!~ m/\|$mygram\|/){$dict="$dict|$mygram";}
delete $freqs[$mi]; delete $grams[$mi];
$cyc++;
}

$dict=~s/\_/ /g;
undef(@txt); undef $txt;
return $dict;
}

sub sen{ #conpute radius from the origin (for classification) of one point with 2 coordinates. parameters= 1 vec with 2 coordinates
@a=split/,/,$_[0];
$x=@a[0]; $y=@a[1];
if($x==0 or $y==0){$sen=0;}else{$sen=$y/sqrt($x**2 + $y**2);}
return $sen;
}

sub sim{ #compute similarity between 2 strings, input: 2 strings
$x=quotemeta(@_[0]); $y=quotemeta(@_[1]);
@x=split//,$x; @y=split//,$y; #$sum=1;
$sum=scalar(@x)+scalar(@y); if($sum==0){$sum=1;}
$match=0;
for($i=0; $i < $sum; $i++ ){
if(@x[$i] == @y[$i] && @x[$i] ne "" && @y[$i] ne ""){$match++ ; } 
}
return sprintf("%.3f",$match/$sum);
}

sub msm{ #compute median, mean and standard deviation of a numeric array
sub mean{
$t=0; $l=1;
foreach my $i (@_){$t=$t+$i; };
$l=scalar(@_); if($l==0){$l=1; }#print "ERR: mu=0 in subroutine\n";
return $t/$l;
}
@v=@_; $t=0; $l=1;
$mu=sprintf("%.3f",mean(@v));
foreach my $i (@_){$t=$t+($i-$mu)**2; };
$l=scalar(@_); if($l==0){$l=1; }#print "ERR: sd=0 in subroutine\n";
$sd=sprintf("%.3f",sqrt($t/$l));
@ov=sort{$a<=>$b}@v;
$mi=int($l/2);
$me=sprintf("%.3f",@ov[$mi]);

return "$me,$mu,$sd";
}


sub tfidf{#return keywords of a text using tf*idf. input $s = string of text, multidocuments are separated by \n
$t=@_[0];
@txt=split/\n/,$t; #take multidocs
$d=scalar(@txt);
%rank=();
foreach my $i (@txt){ 
 $i=~s/[0-9]|\W/ /g; $i=~s/ {2,30}/ /g; 
 @w=split/ /,$i; $n=scalar(@w);
 foreach my $w (@w){$wf++ while $i=~m/ $w /gi; $tf=sprintf("%.3f",$wf/$n); @df=grep/$w/,@txt; $df=scalar(@df); if($df==0){$df=1;}; $idf=sprintf("%.1f",$d/$df); $tfidf=sprintf("%.3f",$tf*$idf); $rank{$w}=$tfidf; $wf=0;}

}

foreach my $k (sort { $rank{$a} <=> $rank{$b} } keys %rank) { 
	if ($rank{$k}<=1){push(@tfidf, $rank{$k}); }}
 return @tfidf;
}
