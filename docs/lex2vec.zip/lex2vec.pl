# Lex2vec v 1.0
# written by Fabio Celli
# fabio.celli.phd@gmail.com
# license CC by-sa https://creativecommons.org/licenses/by-sa/4.0/legalcode


require '.\nrc-en.pl'; #require a dictionary defined as an array of words,definitions

$th=$ARGV[0]; #input theta parameter

open $fh,'<','.\ace04-embeddings.arff'; chomp(@d=<$fh>); close $fh; #open file

@v=grep/^.attribute /,@d; foreach $v(@v){$v=~s/.attribute | numeric//g;} #get header and clean it (for weka files)

#$th=0.8;

$n=scalar(@v); #print("n=$n\n");

foreach $i(@d){
 @e=split/,/,$i;
 if(scalar(@e)==$n){
  $w=quotemeta($e[$n-1]);  #print("processing $w\n");
  @l=grep/$w/,@nrcen;
  if($l[0] ne ''){
   for($j=0; $j < $n-1; $j++ ){
    if($e[$j]>$th or $e[$j]<1-$th){
     if(length($v[$j])<100){ #label truncation by number of characters 
      $v[$j]="$l[0]+$v[$j]"; 
     }
    }
   }
  }
 }
 
}
$tot=0;
foreach $v(@v){
 $eval=$v=~s/ //g; $eval=$eval-2; $tot=$tot+$eval; if($eval==0){$no++;} #compute evaluation
 print("\@attribute $v numeric\n"); #output header
}
print("theta=$th unmatched=".$no/$n.' average='.$tot/$n); #output evaluation


