about Chronos	Chronos is a collaborative project to build a validated historical dataset in tabular format
access levels	commenter access is free, editor access is available upon request
license	creative commons attribution - non commercial - share alike https://creativecommons.org/licenses/by-nc-sa/4.0/deed.en
usage	header contains a description of column content. each cell can be commented proposing changes
versioning and compatibility	Chronos releases have a name followed by a number indicating the compatibility. Dataset with the same compatibility number have the same rows. each dataset has a different tab in this spreadsheet. the ""dev"" tab is the current version under development"

https://docs.google.com/spreadsheets/d/1OW6CtmUudN3WTJ1VvWRZYZdTWVEjDJGns6Q8_I6EBwk

please cite 

Celli, Fabio, and Valerio Basile. "History Repeats: Historical Phase Recognition from Short Texts." (2024). in Proceedings of the Tenth Italian Conference on Computational Linguistics (CLiC-it 2024), Pisa, Italy,