#!/usr/bin/perl

=cut
.input. read file(should be jpg) and directory, 

.level0:encoding(picture header)
.level1:frequency(freq of all hex values)


=cut

 my $sin=$ARGV[0]; chomp($sin);  my $ext=$ARGV[1]; chomp($ext); #catch inputs
#print @ARGV;

if($sin eq '' && $ext eq ''){#if input is empty print help

print 'IATo (Image Analysis Tool)
v1.0
is a feature extraction tool for images
written by Fabio Celli at the 
University of Trento.

LICENSE: creative common by-nc-sa 3.0
you can use this code only for research purposes
you can modify it 
you always have to cite the author
you cannot use it for commercial purposes.
Please contact the author (fabio.celli@live.it)
for different licensing.

IN AND OUT: you can process all files in a folder 
or a single file.
the output is a .csv printed on screen, to save it in a file 
the system takes two parameters as input:
-a directory or file
-the image extension you wnt to process
use the following syntax:
perl iato1.pl [dir/file.jpg|dir] [.jpg] > youroutput.csv

';
}else{ #else process the input
 
if($sin=~m/\....$/i){@f=split/\\/,$sin; $file=pop(@f); $dir=join("/", @f);}else{$dir=$sin;} #split dir and file
chdir($dir); #go to dir
($s, $m, $h ) = localtime(); print "started at: $h.$m.$s\n"; #start time
 #open my $out, ">", "iato1-feat.arff";  
 #open my $out2, ">", "$file-article.tab";
 #$header=<$in>;  @h=split/\t/,$header; $nclass=scalar(@h); $nclass=$nclass-1; #count num of classes to generate attributes in arff file
=cut
@files = </var/www/htdocs/*.jpg>;
foreach $file (@files) {
  print $file . "\n";
}
=cut
print  "id,x00,x01,x02,x03,x04,x05,x06,x07,x08,x09,x0A,x0B,x0C,x0D,x0E,x0F,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,x1A,x1B,x1C,x1D,x1E,x1F,x20,x21,x22,x23,x24,x25,x26,x27,x28,x29,x2A,x2B,x2C,x2D,x2E,x2F,x30,x31,x32,x33,x34,x35,x36,x37,x38,x39,x3A,x3B,x3C,x3D,x3E,x3F,x40,x41,x42,x43,x44,x45,x46,x47,x48,x49,x4A,x4B,x4C,x4D,x4E,x4F,x50,x51,x52,x53,x54,x55,x56,x57,x58,x59,x5A,x5B,x5C,x5D,x5E,x5F,x60,x61,x62,x63,x64,x65,x66,x67,x68,x69,x6A,x6B,x6C,x6D,x6E,x6F,x70,x71,x72,x73,x74,x75,x76,x77,x78,x79,x7A,x7B,x7C,x7D,x7E,x7F,x80,x81,x82,x83,x84,x85,x86,x87,x88,x89,x8A,x8B,x8C,x8D,x8E,x8F,x90,x91,x92,x93,x94,x95,x96,x97,x98,x99,x9A,x9B,x9C,x9D,x9E,x9F,xA0,xA1,xA2,xA3,xA4,xA5,xA6,xA7,xA8,xA9,xAA,xAB,xAC,xAD,xAE,xAF,xB0,xB1,xB2,xB3,xB4,xB5,xB6,xB7,xB8,xB9,xBA,xBB,xBC,xBD,xBE,xBF,xC0,xC1,xC2,xC3,xC4,xC5,xC6,xC7,xC8,xC9,xCA,xCB,xCC,xCD,xCE,xCF,xD0,xD1,xD2,xD3,xD4,xD5,xD6,xD7,xD8,xD9,xDA,xDB,xDC,xDD,xDE,xDF,xE0,xE1,xE2,xE3,xE4,xE5,xE6,xE7,xE8,xE9,xEA,xEB,xEC,xED,xEE,xEF,xF0,xF1,xF2,xF3,xF4,xF5,xF6,xF7,xF8,xF9,xFA,xFB,xFC,xFD,xFE,xFF
";


#process

#my $d = do {local $/ = undef; open my $fh, "<", $file or die "could not open $file: $!";  <$fh>;}; #catch data into a string
opendir(DIR, $dir) or die "cannot open directory";
 while (my $file = readdir(DIR)) {#print "$file ext= $ext";
 if($file=~m/$ext/i){ 
  my $d = do {local $/ = undef; open my $fh, "<", $file or die "could not open $file: $!";  <$fh>;}; #catch data into a string

$file=~s/\.+//i; $id=$file;

$level0=""; $level1="";


if($d eq ""){next; }else{

#===level0:encoding
 $bytes=length($d); #extract weight
 
#===level1:frequency
 $fi=$d=~s/\x00//g; $x01=$d=~s/\x01//g; $x02=$d=~s/\x02//g; $x03=$d=~s/\x03//g; $x04=$d=~s/\x04//g; $x05=$d=~s/\x05//g; $x06=$d=~s/\x06//g; $x07=$d=~s/\x07//g; $x08=$d=~s/\x08//g; $x09=$d=~s/\x09//g; $x0A=$d=~s/\x0A//g; $x0B=$d=~s/\x0B//g; $x0C=$d=~s/\x0C//g; $x0D=$d=~s/\x0D//g; $x0E=$d=~s/\x0E//g; $x0F=$d=~s/\x0F//g; $level1="$level1$fi,$x01,$x02,$x03,$x04,$x05,$x06,$x07,$x08,$x09,$x0A,$x0B,$x0C,$x0D,$x0E,$x0F,";
 $x10=$d=~s/\x10//g; $x11=$d=~s/\x11//g; $x12=$d=~s/\x12//g; $x13=$d=~s/\x13//g; $x14=$d=~s/\x14//g; $x15=$d=~s/\x15//g; $x16=$d=~s/\x16//g; $x17=$d=~s/\x17//g; $x18=$d=~s/\x18//g; $x19=$d=~s/\x19//g; $x1A=$d=~s/\x1A//g; $x1B=$d=~s/\x1B//g; $x1C=$d=~s/\x1C//g; $x1D=$d=~s/\x1D//g; $x1E=$d=~s/\x1E//g; $x1F=$d=~s/\x1F//g; $level1="$level1$x10,$x11,$x12,$x13,$x14,$x15,$x16,$x17,$x18,$x19,$x1A,$x1B,$x1C,$x1D,$x1E,$x1F,";
 $x20=$d=~s/\x20//g; $x21=$d=~s/\x21//g; $x22=$d=~s/\x22//g; $x23=$d=~s/\x23//g; $x24=$d=~s/\x24//g; $x25=$d=~s/\x25//g; $x26=$d=~s/\x26//g; $x27=$d=~s/\x27//g; $x28=$d=~s/\x28//g; $x29=$d=~s/\x29//g; $x2A=$d=~s/\x2A//g; $x2B=$d=~s/\x2B//g; $x2C=$d=~s/\x2C//g; $x2D=$d=~s/\x2D//g; $x2E=$d=~s/\x2E//g; $x2F=$d=~s/\x2F//g; $level1="$level1$x20,$x21,$x22,$x23,$x24,$x25,$x26,$x27,$x28,$x29,$x2A,$x2B,$x2C,$x2D,$x2E,$x2F,";
 $x30=$d=~s/\x30//g; $x31=$d=~s/\x31//g; $x32=$d=~s/\x32//g; $x33=$d=~s/\x33//g; $x34=$d=~s/\x34//g; $x35=$d=~s/\x35//g; $x36=$d=~s/\x36//g; $x37=$d=~s/\x37//g; $x38=$d=~s/\x38//g; $x39=$d=~s/\x39//g; $x3A=$d=~s/\x3A//g; $x3B=$d=~s/\x3B//g; $x3C=$d=~s/\x3C//g; $x3D=$d=~s/\x3D//g; $x3E=$d=~s/\x3E//g; $x3F=$d=~s/\x3F//g; $level1="$level1$x30,$x31,$x32,$x33,$x34,$x35,$x36,$x37,$x38,$x39,$x3A,$x3B,$x3C,$x3D,$x3E,$x3F,";
 $x40=$d=~s/\x40//g; $x41=$d=~s/\x41//g; $x42=$d=~s/\x42//g; $x43=$d=~s/\x43//g; $x44=$d=~s/\x44//g; $x45=$d=~s/\x45//g; $x46=$d=~s/\x46//g; $x47=$d=~s/\x47//g; $x48=$d=~s/\x48//g; $x49=$d=~s/\x49//g; $x4A=$d=~s/\x4A//g; $x4B=$d=~s/\x4B//g; $x4C=$d=~s/\x4C//g; $x4D=$d=~s/\x4D//g; $x4E=$d=~s/\x4E//g; $x4F=$d=~s/\x4F//g; $level1="$level1$x40,$x41,$x42,$x43,$x44,$x45,$x46,$x47,$x48,$x49,$x4A,$x4B,$x4C,$x4D,$x4E,$x4F,";
 $x50=$d=~s/\x50//g; $x51=$d=~s/\x51//g; $x52=$d=~s/\x52//g; $x53=$d=~s/\x53//g; $x54=$d=~s/\x54//g; $x55=$d=~s/\x55//g; $x56=$d=~s/\x56//g; $x57=$d=~s/\x57//g; $x58=$d=~s/\x58//g; $x59=$d=~s/\x59//g; $x5A=$d=~s/\x5A//g; $x5B=$d=~s/\x5B//g; $x5C=$d=~s/\x5C//g; $x5D=$d=~s/\x5D//g; $x5E=$d=~s/\x5E//g; $x5F=$d=~s/\x5F//g; $level1="$level1$x50,$x51,$x52,$x53,$x54,$x55,$x56,$x57,$x58,$x59,$x5A,$x5B,$x5C,$x5D,$x5E,$x5F,";
 $x60=$d=~s/\x60//g; $x61=$d=~s/\x61//g; $x62=$d=~s/\x62//g; $x63=$d=~s/\x63//g; $x64=$d=~s/\x64//g; $x65=$d=~s/\x65//g; $x66=$d=~s/\x66//g; $x67=$d=~s/\x67//g; $x68=$d=~s/\x68//g; $x69=$d=~s/\x69//g; $x6A=$d=~s/\x6A//g; $x6B=$d=~s/\x6B//g; $x6C=$d=~s/\x6C//g; $x6D=$d=~s/\x6D//g; $x6E=$d=~s/\x6E//g; $x6F=$d=~s/\x6F//g; $level1="$level1$x60,$x61,$x62,$x63,$x64,$x65,$x66,$x67,$x68,$x69,$x6A,$x6B,$x6C,$x6D,$x6E,$x6F,";
 $x70=$d=~s/\x70//g; $x71=$d=~s/\x71//g; $x72=$d=~s/\x72//g; $x73=$d=~s/\x73//g; $x74=$d=~s/\x74//g; $x75=$d=~s/\x75//g; $x76=$d=~s/\x76//g; $x77=$d=~s/\x77//g; $x78=$d=~s/\x78//g; $x79=$d=~s/\x79//g; $x7A=$d=~s/\x7A//g; $x7B=$d=~s/\x7B//g; $x7C=$d=~s/\x7C//g; $x7D=$d=~s/\x7D//g; $x7E=$d=~s/\x7E//g; $x7F=$d=~s/\x7F//g; $level1="$level1$x70,$x71,$x72,$x73,$x74,$x75,$x76,$x77,$x78,$x79,$x7A,$x7B,$x7C,$x7D,$x7E,$x7F,";
 $x80=$d=~s/\x80//g; $x81=$d=~s/\x81//g; $x82=$d=~s/\x82//g; $x83=$d=~s/\x83//g; $x84=$d=~s/\x84//g; $x85=$d=~s/\x85//g; $x86=$d=~s/\x86//g; $x87=$d=~s/\x87//g; $x88=$d=~s/\x88//g; $x89=$d=~s/\x89//g; $x8A=$d=~s/\x8A//g; $x8B=$d=~s/\x8B//g; $x8C=$d=~s/\x8C//g; $x8D=$d=~s/\x8D//g; $x8E=$d=~s/\x8E//g; $x8F=$d=~s/\x8F//g; $level1="$level1$x80,$x81,$x82,$x83,$x84,$x85,$x86,$x87,$x88,$x89,$x8A,$x8B,$x8C,$x8D,$x8E,$x8F,";
 $x90=$d=~s/\x90//g; $x91=$d=~s/\x91//g; $x92=$d=~s/\x92//g; $x93=$d=~s/\x93//g; $x94=$d=~s/\x94//g; $x95=$d=~s/\x95//g; $x96=$d=~s/\x96//g; $x97=$d=~s/\x97//g; $x98=$d=~s/\x98//g; $x99=$d=~s/\x99//g; $x9A=$d=~s/\x9A//g; $x9B=$d=~s/\x9B//g; $x9C=$d=~s/\x9C//g; $x9D=$d=~s/\x9D//g; $x9E=$d=~s/\x9E//g; $x9F=$d=~s/\x9F//g; $level1="$level1$x90,$x91,$x92,$x93,$x94,$x95,$x96,$x97,$x98,$x99,$x9A,$x9B,$x9C,$x9D,$x9E,$x9F,";
 $xA0=$d=~s/\xA0//g; $xA1=$d=~s/\xA1//g; $xA2=$d=~s/\xA2//g; $xA3=$d=~s/\xA3//g; $xA4=$d=~s/\xA4//g; $xA5=$d=~s/\xA5//g; $xA6=$d=~s/\xA6//g; $xA7=$d=~s/\xA7//g; $xA8=$d=~s/\xA8//g; $xA9=$d=~s/\xA9//g; $xAA=$d=~s/\xAA//g; $xAB=$d=~s/\xAB//g; $xAC=$d=~s/\xAC//g; $xAD=$d=~s/\xAD//g; $xAE=$d=~s/\xAE//g; $xAF=$d=~s/\xAF//g; $level1="$level1$xA0,$xA1,$xA2,$xA3,$xA4,$xA5,$xA6,$xA7,$xA8,$xA9,$xAA,$xAB,$xAC,$xAD,$xAE,$xAF,";
 $xB0=$d=~s/\xB0//g; $xB1=$d=~s/\xB1//g; $xB2=$d=~s/\xB2//g; $xB3=$d=~s/\xB3//g; $xB4=$d=~s/\xB4//g; $xB5=$d=~s/\xB5//g; $xB6=$d=~s/\xB6//g; $xB7=$d=~s/\xB7//g; $xB8=$d=~s/\xB8//g; $xB9=$d=~s/\xB9//g; $xBA=$d=~s/\xBA//g; $xBB=$d=~s/\xBB//g; $xBC=$d=~s/\xBC//g; $xBD=$d=~s/\xBD//g; $xBE=$d=~s/\xBE//g; $xBF=$d=~s/\xBF//g; $level1="$level1$xB0,$xB1,$xB2,$xB3,$xB4,$xB5,$xB6,$xB7,$xB8,$xB9,$xBA,$xBB,$xBC,$xBD,$xBE,$xBF,";
 $xC0=$d=~s/\xC0//g; $xC1=$d=~s/\xC1//g; $xC2=$d=~s/\xC2//g; $xC3=$d=~s/\xC3//g; $xC4=$d=~s/\xC4//g; $xC5=$d=~s/\xC5//g; $xC6=$d=~s/\xC6//g; $xC7=$d=~s/\xC7//g; $xC8=$d=~s/\xC8//g; $xC9=$d=~s/\xC9//g; $xCA=$d=~s/\xCA//g; $xCB=$d=~s/\xCB//g; $xCC=$d=~s/\xCC//g; $xCD=$d=~s/\xCD//g; $xCE=$d=~s/\xCE//g; $xCF=$d=~s/\xCF//g; $level1="$level1$xC0,$xC1,$xC2,$xC3,$xC4,$xC5,$xC6,$xC7,$xC8,$xC9,$xCA,$xCB,$xCC,$xCD,$xCE,$xCF,";
 $xD0=$d=~s/\xD0//g; $xD1=$d=~s/\xD1//g; $xD2=$d=~s/\xD2//g; $xD3=$d=~s/\xD3//g; $xD4=$d=~s/\xD4//g; $xD5=$d=~s/\xD5//g; $xD6=$d=~s/\xD6//g; $xD7=$d=~s/\xD7//g; $xD8=$d=~s/\xD8//g; $xD9=$d=~s/\xD9//g; $xDA=$d=~s/\xDA//g; $xDB=$d=~s/\xDB//g; $xDC=$d=~s/\xDC//g; $xDD=$d=~s/\xDD//g; $xDE=$d=~s/\xDE//g; $xDF=$d=~s/\xDF//g; $level1="$level1$xD0,$xD1,$xD2,$xD3,$xD4,$xD5,$xD6,$xD7,$xD8,$xD9,$xDA,$xDB,$xDC,$xDD,$xDE,$xDF,";
 $xE0=$d=~s/\xE0//g; $xE1=$d=~s/\xE1//g; $xE2=$d=~s/\xE2//g; $xE3=$d=~s/\xE3//g; $xE4=$d=~s/\xE4//g; $xE5=$d=~s/\xE5//g; $xE6=$d=~s/\xE6//g; $xE7=$d=~s/\xE7//g; $xE8=$d=~s/\xE8//g; $xE9=$d=~s/\xE9//g; $xEA=$d=~s/\xEA//g; $xEB=$d=~s/\xEB//g; $xEC=$d=~s/\xEC//g; $xED=$d=~s/\xED//g; $xEE=$d=~s/\xEE//g; $xEF=$d=~s/\xEF//g; $level1="$level1$xE0,$xE1,$xE2,$xE3,$xE4,$xE5,$xE6,$xE7,$xE8,$xE9,$xEA,$xEB,$xEC,$xED,$xEE,$xEF,";
 $xF0=$d=~s/\xF0//g; $xF1=$d=~s/\xF1//g; $xF2=$d=~s/\xF2//g; $xF3=$d=~s/\xF3//g; $xF4=$d=~s/\xF4//g; $xF5=$d=~s/\xF5//g; $xF6=$d=~s/\xF6//g; $xF7=$d=~s/\xF7//g; $xF8=$d=~s/\xF8//g; $xF9=$d=~s/\xF9//g; $xFA=$d=~s/\xFA//g; $xFB=$d=~s/\xFB//g; $xFC=$d=~s/\xFC//g; $xFD=$d=~s/\xFD//g; $xFE=$d=~s/\xFE//g; $xFF=$d=~s/\xFF//g; $level1="$level1$xF0,$xF1,$xF2,$xF3,$xF4,$xF5,$xF6,$xF7,$xF8,$xF9,$xFA,$xFB,$xFC,$xFD,$xFE,$xFF";

#===level2:raw image data
 @d=split//,$d; foreach my $i (@d){ $i=sprintf("%d",ord($i));}; #@ds=sort{$a<=>$b}@d;
 #$n=($bytes/2); 
 #print @d;

 @l1=split/,/,$level1; foreach my $i (@l1){ $i=sprintf("%.4f",($i/$bytes));}; $level1=join(',',@l1);

# $ng1=ngrams($d, 1, 1); print "\n ng1=$ng1 \n"; @ng1=split/\|/,$ng1; $ng1c=scalar(@ng1); #extract 1grams min freq 5
# $ng2=ngrams($d, 2, 4); @ng2=split/\|/,$ng2; $ng2c=scalar(@ng2);
# $ng4=ngrams($d, 4, 2); @ng4=split/\|/,$ng4; $ng4c=scalar(@ng4);
# $ng8=ngrams($d, 8, 2); @ng8=split/\|/,$ng8; $ng8c=scalar(@ng8);

$id=~s/\.+//g;
#===output
$output="'$id',$level1\n"; $output=~s/,,/,\?,/g; #$output=~s/,,/,\?,/g;
print $output;

  }
 }
}


($s, $m, $h ) = localtime(); print "finished at: $h.$m.$s\n"; #end time
  

}
