IATo v1.0




IATo (Image Analysis Tool)
v1.0
is a feature extraction tool for images
written by Fabio Celli at the
University of Trento.


REQUIREMENTS
IATo is a open source Image Analysis tool based written in Perl.
Perl v 5.10 or above is required to run IATo.
To run the code, 
-install perl, 
-set perl path in the environment variable or put IATo in the path of perl
-execute IATo typing: perl iato1.pl

LICENSE
creative common by-nc-sa 3.0
you can use this code only for research purposes
you can modify it
you always have to cite the author
you cannot use it for commercial purposes.
Please contact the author (fabio.celli@live.it)
for different licensing.

CITING IATo
chicago style:
 Segalin, Cristina, Fabio Celli, Luca Polonio, Michal Kosinski, David Stillwell, Nicu Sebe, Marco Cristani, and Bruno Lepri. 
 "What your Facebook profile picture reveals about your personality." 
 In Proceedings of the 2017 ACM on Multimedia Conference, pp. 460-468. ACM, 2017.
in bibtex:
@inproceedings{segalin2017your,
  title={What your Facebook profile picture reveals about your personality},
  author={Segalin, Cristina and Celli, Fabio and Polonio, Luca and Kosinski, Michal and Stillwell, David and Sebe, Nicu and Cristani, Marco and Lepri, Bruno},
  booktitle={Proceedings of the 2017 ACM on Multimedia Conference},
  pages={460--468},
  year={2017},
  organization={ACM}
}

PROCESSING
you can process all files in a folder
or a single file.
the output is a .csv printed on screen, to save it in a file
the system takes two parameters as input:
-a directory or file
-the image extension you wnt to process
use the following syntax:
perl iato1.pl [dir/file.jpg|dir] [.jpg] > youroutput.csv


